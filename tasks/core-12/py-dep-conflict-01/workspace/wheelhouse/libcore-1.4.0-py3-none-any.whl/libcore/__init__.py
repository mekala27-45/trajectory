"""Core primitives, 1.x series."""

__version__ = "1.4.0"
API_LEVEL = 1


def normalise(text):
    """Lowercase and strip. The 1.x behaviour, which collapses inner whitespace too."""
    return " ".join(text.lower().split())
