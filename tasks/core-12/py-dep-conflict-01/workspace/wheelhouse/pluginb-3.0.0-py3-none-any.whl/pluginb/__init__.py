"""Export plugin, built against the libcore 2.x API."""

__version__ = "3.0.0"

from libcore import fingerprint, normalise


def export(rows):
    """Return one normalised line per row."""
    return [normalise(row) for row in rows]


def export_with_ids(rows):
    """Return normalised lines paired with their fingerprints."""
    return [(normalise(row), fingerprint(row)) for row in rows]
