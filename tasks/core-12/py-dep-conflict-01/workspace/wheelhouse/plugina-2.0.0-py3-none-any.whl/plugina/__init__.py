"""Reporting plugin, built against the libcore 2.x API."""

__version__ = "2.0.0"

from libcore import fingerprint, normalise


def title(text):
    """Return a display title."""
    return normalise(text).title()


def slug(text):
    """Return a stable slug, using the 2.x fingerprint."""
    return f"{normalise(text).replace(' ', '-')}-{fingerprint(text)}"
