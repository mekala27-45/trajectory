"""Core primitives, 2.x series."""

__version__ = "2.1.0"
API_LEVEL = 2


def normalise(text, *, collapse=True):
    """Lowercase and strip, with inner whitespace collapsing now optional."""
    lowered = text.lower().strip()
    return " ".join(lowered.split()) if collapse else lowered


def fingerprint(text):
    """Stable short hash of the normalised text. New in 2.x."""
    import hashlib

    return hashlib.sha256(normalise(text).encode()).hexdigest()[:12]
