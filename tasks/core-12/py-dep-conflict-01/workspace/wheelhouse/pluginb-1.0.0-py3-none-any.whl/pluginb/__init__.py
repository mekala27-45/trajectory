"""Export plugin, built against the libcore 1.x API."""

__version__ = "1.0.0"

from libcore import normalise


def export(rows):
    """Return one normalised line per row."""
    return [normalise(row) for row in rows]
