"""Reporting plugin, built against the libcore 1.x API."""

__version__ = "1.0.0"

from libcore import normalise


def title(text):
    """Return a display title."""
    return normalise(text).title()
